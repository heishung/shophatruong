<?php 
//Silence is golden