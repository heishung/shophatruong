<div class="right_sidebar">
			<div class="wpmm-upgrade-banner">
              <img src="<?php echo APMM_IMG_DIR;?>/banner-image-pro.jpg" alt="upgrade-banner-top">
              <div class="wpmm-button-wrap-backend">
                <a href="http://demo.accesspressthemes.com/wordpress-plugins/wp-mega-menu-pro/" class="wpmm-demo-btn" target="_blank">Demo</a>
                <a href="https://codecanyon.net/item/wp-mega-menu-pro-responsive-mega-menu-plugin-for-wordpress/19190840?ref=AccessKeys" target="_blank" class="wpmm-upgrade-btn">Upgrade</a>
                <a href="https://accesspressthemes.com/wordpress-plugins/wp-mega-menu-pro/" target="_blank" class="wpmm-upgrade-btn">Plugin Information</a>
              </div>
            <img src="<?php echo APMM_IMG_DIR;?>/banner-feature-pro.jpg" alt="upgrade-banner-bottom">
        </div>

</div>